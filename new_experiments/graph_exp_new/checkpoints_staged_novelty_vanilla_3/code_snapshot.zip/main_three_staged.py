"""
Three-Staged Pipeline  generator trained directly on task loss.

Stage 1: Pretrain GraphTransformer  freeze (identical to main_staged.py)
Stage 2: Train generator on task loss through frozen transformer (NEW)
Stage 3: End-to-end fine-tune with Phase A (frozen transformer, reduced LR)
         + Phase B (unfreeze transformer at 0.1x gen LR) + proxy dropout

Usage:
    python main_three_staged.py --stage all --generator score_based
    python main_three_staged.py --stage 2 --model_path checkpoints_three_staged/stage1_best.pt
    python main_three_staged.py --stage 3 --model_path ... --generator_path ...
"""

import argparse
import os
import pickle
import time
import yaml
import numpy as np
import torch
torch.set_float32_matmul_precision('high')
import torch.nn as nn
import torch.nn.functional as F

from data import get_loaders
from models import GraphTransformer, GREDEncoder, GREDHybridTransformer
from generators import (
    ScoreBasedGenerator, GNNPoolingGenerator, PMAGenerator, GraphCoarseningGenerator,
    CrossAttentionRouter, MultiPointProxyWrapper,
)
from metrics import compute_macro_ap
from losses import novelty_loss, inter_proxy_cosine_stats, proxy_diversity_loss
from optim_utils import (
    build_grouped_optimizer_and_scheduler,
    build_warmup_cosine_scheduler,
)

import warnings

warnings.filterwarnings(
    "ignore",
    message="k >= N for N \\* N square matrix",
    category=RuntimeWarning
)
# ================================================================
# CONFIG
# ================================================================

def build_parser():
    p = argparse.ArgumentParser(description="Three-Staged Pipeline: task-loss generator training")
    p.add_argument("--config", type=str, default=None)
    p.add_argument("--stage", type=str, default="all",
                   choices=["1", "2", "3", "all"])
    p.add_argument("--generator", type=str, default="graph_coarsening",
                   choices=["score_based", "pma", "graph_coarsening", "gnn_pooling"])

    # Backbone
    p.add_argument("--backbone", type=str, default="vanilla_gt",
                   choices=["vanilla_gt", "gred", "hybrid"],
                   help="Backbone architecture: vanilla_gt, gred, or hybrid")

    # Paths (for resuming individual stages)
    p.add_argument("--model_path", type=str, default=None,
                   help="Pretrained transformer checkpoint (skip stage 1)")
    p.add_argument("--generator_path", type=str, default=None,
                   help="Trained generator checkpoint (skip stage 2)")

    # Transformer model
    p.add_argument("--hidden_dim", type=int, default=256)
    p.add_argument("--num_layers", type=int, default=5)
    p.add_argument("--num_heads", type=int, default=8)
    p.add_argument("--output_dim", type=int, default=10)
    p.add_argument("--dropout", type=float, default=0.1)
    p.add_argument("--num_proxies", type=int, default=32)

    # Laplacian positional encoding
    p.add_argument("--use_lap_pe", action=argparse.BooleanOptionalAction, default=True,
                   help="Add Laplacian eigenvector positional encodings to node features")
    p.add_argument("--lap_pe_dim", type=int, default=8,
                   help="Number of Laplacian eigenvectors for positional encoding")

    # GRED-specific
    p.add_argument("--state_dim", type=int, default=88,
                   help="LRU complex state dimension (GRED/hybrid only)")
    p.add_argument("--num_gred_layers", type=int, default=8,
                   help="Number of GRED layers (GRED/hybrid only)")
    p.add_argument("--num_transformer_layers", type=int, default=2,
                   help="Number of transformer layers for proxy integration (hybrid only)")
    p.add_argument("--gred_expand", type=int, default=1,
                   help="FFN expansion factor for GRED DeepSets MLP")
    p.add_argument("--r_min", type=float, default=0.0)
    p.add_argument("--r_max", type=float, default=1.0)
    p.add_argument("--max_phase", type=float, default=6.28)
    p.add_argument("--gred_act", type=str, default="full-glu",
                   choices=["full-glu", "half-glu"])
    p.add_argument("--max_hops", type=int, default=40)
    p.add_argument("--dist_mask_workers", type=int, default=8)

    # Stage 1  Pretrain transformer
    p.add_argument("--s1_lr", type=float, default=1e-3)
    p.add_argument("--s1_weight_decay", type=float, default=3e-4)
    p.add_argument("--s1_max_epochs", type=int, default=300)
    p.add_argument("--s1_patience", type=int, default=50)
    p.add_argument("--s1_grad_clip", type=float, default=1.0)

    # Stage 2 - Train generator on task loss
    p.add_argument("--s2_lr", type=float, default=1e-3)
    p.add_argument("--s2_weight_decay", type=float, default=3e-4)
    p.add_argument("--s2_max_epochs", type=int, default=500)
    p.add_argument("--s2_patience", type=int, default=50)
    p.add_argument("--s2_eval_every", type=int, default=1)
    p.add_argument("--s2_grad_clip", type=float, default=1.0)

    # Stage 3 - End-to-end finetune
    p.add_argument("--s3_phase_a_epochs", type=int, default=5,
                   help="Epochs to keep transformer frozen before Phase B")
    p.add_argument("--s3_lr_gen", type=float, default=5e-4,
                   help="Generator LR for stage 3 (default: 0.1 * s2_lr)")
    p.add_argument("--s3_lr_transformer", type=float, default=5e-4,
                   help="Transformer LR for Phase B (default: 0.1 * s3_lr_gen)")
    p.add_argument("--s3_proxy_dropout", type=float, default=0.1,
                   help="Fraction of batches that train without proxies")
    p.add_argument("--s3_max_epochs", type=int, default=500)
    p.add_argument("--s3_patience", type=int, default=50)
    p.add_argument("--s3_grad_clip", type=float, default=1.0)
    p.add_argument("--s3_weight_decay", type=float, default=1e-4)

    # Novelty loss hyperparameters
    p.add_argument("--novelty_alpha", type=float, default=0.0,
                   help="Weight for novelty loss. 0 disables novelty loss.")

    # Proxy diversity loss
    p.add_argument("--diversity_weight", type=float, default=0.0,
                   help="Weight for proxy diversity loss. 0 disables.")

    # Generator architecture
    p.add_argument("--gen_hidden_dim", type=int, default=256)
    p.add_argument("--gen_num_layers", type=int, default=4)
    p.add_argument("--gen_num_heads", type=int, default=8)
    p.add_argument("--gen_dropout", type=float, default=0.2)
    # PMA specific
    p.add_argument("--pma_query_mode", type=str, default="farthest_point",
                   choices=["farthest_point", "soft_kmeans"])
    # Graph coarsening specific
    p.add_argument("--coarsen_gnn_type", type=str, default="GIN",
                   choices=["GIN", "GCN"])
    p.add_argument("--coarsen_reg_weight", type=float, default=0.1)
    p.add_argument("--coarsen_reg_type", type=str, default="mincut")
    # GNN pooling specific (kept for ablation)
    p.add_argument("--gnn_layers", type=int, default=4)
    p.add_argument("--gnn_type", type=str, default="GINE",
                   choices=["GCN", "GIN", "GINE", "GAT"])
    p.add_argument("--pool_types", type=str, nargs="+", default=["max"])
    p.add_argument("--decode_hidden", type=int, default=128)
    p.add_argument("--decode_layers", type=int, default=3)
    p.add_argument("--idx_emb_dim", type=int, default=128)
    p.add_argument("--decode_mode", type=str, default="shared",
                   choices=["shared", "grouped"])

    # Cross-attention routing (N→M→N)
    p.add_argument("--use_cross_attn_routing", action="store_true", default=False,
                   help="Use N→M→N cross-attention routing instead of N+M concat")
    p.add_argument("--num_cross_layers", type=int, default=2,
                   help="Number of N→M→N routing layers (only with --use_cross_attn_routing)")
    p.add_argument("--cross_attn_proxy_self_attn", action=argparse.BooleanOptionalAction,
                   default=True,
                   help="Include M×M self-attention within cross-attention routing")

    # Multi-point proxy insertion
    p.add_argument("--proxy_insertion_layers", type=str, default="-1",
                   help="Comma-separated layer indices for multi-point proxy insertion. "
                        "-1 = no insertion (default). 0 = before layer 0 (like current). "
                        "E.g., '0,2,4' for three insertion points.")
    p.add_argument("--separate_proxy_generators", action="store_true", default=False,
                   help="Use independent generator per insertion point (Option B).")
    p.add_argument("--separate_proxy_routers", action="store_true", default=False,
                   help="Use independent router per insertion point.")
    p.add_argument("--proxy_aux_loss_decay", type=float, default=1.0,
                   help="Geometric decay factor for multi-point aux losses.")

    # Common
    p.add_argument("--readout_scope", type=str, default="all_tokens", help="all_tokens or nodes_only")
    p.add_argument("--batch_size", type=int, default=32)
    p.add_argument("--num_workers", type=int, default=4)
    p.add_argument("--lr_min", type=float, default=1e-7,
                   help="Minimum LR floor for warmup-cosine schedule")
    p.add_argument("--warmup_ratio", type=float, default=0.05,
                   help="Warmup fraction of total optimization steps")
    p.add_argument("--recurrent_lr_factor", type=float, default=1.0,
                   help="LR multiplier for recurrent GRED parameters")
    p.add_argument("--save_dir", type=str, default="checkpoints_three_staged")
    p.add_argument("--device", type=str, default=None)

    return p


def parse_args():
    parser = build_parser()
    preliminary, _ = parser.parse_known_args()
    if preliminary.config is not None:
        with open(preliminary.config, "r") as f:
            yaml_cfg = yaml.safe_load(f)
        parser.set_defaults(**yaml_cfg)
    args = parser.parse_args()
    if args.device is None:
        args.device = "cuda" if torch.cuda.is_available() else "cpu"
    # Derive Stage 3 LRs from Stage 2 LR if not set
    if args.s3_lr_gen is None:
        args.s3_lr_gen = args.s2_lr * 0.1
    if args.s3_lr_transformer is None:
        args.s3_lr_transformer = args.s3_lr_gen * 0.1
    print(args.__dict__)
    return args


def save_code_snapshot(save_dir):
    import zipfile
    code_files = [f for f in os.listdir(".") if f.endswith(".py")]
    zip_path = os.path.join(save_dir, "code_snapshot.zip")
    with zipfile.ZipFile(zip_path, "w") as zf:
        for f in code_files:
            zf.write(f)
    print(f"Saved code snapshot to {zip_path}", flush=True)


# ================================================================
# HELPERS
# ================================================================

def _freeze(model):
    for p in model.parameters():
        p.requires_grad_(False)


def _unfreeze(model):
    for p in model.parameters():
        p.requires_grad_(True)


def _uses_flat_interface(generator_name):
    """True for generators that need flat (total_N, d) embeddings + edge_index."""
    return generator_name in ("graph_coarsening", "gnn_pooling")


def _build_cross_attn_router(args):
    """Build CrossAttentionRouter if --use_cross_attn_routing is set."""
    if getattr(args, 'use_cross_attn_routing', False):
        return CrossAttentionRouter(
            hidden_dim=args.hidden_dim,
            num_heads=args.num_heads,
            num_cross_layers=args.num_cross_layers,
            dropout=args.dropout,
            use_proxy_self_attn=args.cross_attn_proxy_self_attn,
        )
    return None


def _parse_insertion_layers(s):
    """Parse '--proxy_insertion_layers' string into a sorted list or None."""
    layers = [int(x.strip()) for x in s.split(",")]
    if layers == [-1]:
        return None  # disabled
    return sorted(layers)


def _build_multi_point_proxy(args, generator, router):
    """Build MultiPointProxyWrapper if multi-point is enabled."""
    layers = _parse_insertion_layers(args.proxy_insertion_layers)
    if layers is None:
        return None
    return MultiPointProxyWrapper(
        generator=generator,
        router=router,  # None when not using cross-attn routing
        insertion_layers=layers,
        separate_generators=args.separate_proxy_generators,
        separate_routers=args.separate_proxy_routers,
        aux_loss_decay=args.proxy_aux_loss_decay,
    )


def build_model(args):
    """Build backbone model based on --backbone arg."""
    lap_pe_dim = args.lap_pe_dim if args.use_lap_pe else 0
    cross_attn_router = _build_cross_attn_router(args)
    if args.backbone == "vanilla_gt":
        return GraphTransformer(
            num_layers=args.num_layers, num_heads=args.num_heads,
            hidden_dim=args.hidden_dim, output_dim=args.output_dim,
            dropout=args.dropout, lap_pe_dim=lap_pe_dim,
            cross_attn_router=cross_attn_router,
        )
    elif args.backbone == "gred":
        return GREDEncoder(
            hidden_dim=args.hidden_dim, state_dim=args.state_dim,
            num_layers=args.num_gred_layers, expand=args.gred_expand,
            r_min=args.r_min, r_max=args.r_max, max_phase=args.max_phase,
            dropout=args.dropout, act=args.gred_act, output_dim=args.output_dim,
            lap_pe_dim=lap_pe_dim,
        )
    elif args.backbone == "hybrid":
        return GREDHybridTransformer(
            hidden_dim=args.hidden_dim, state_dim=args.state_dim,
            num_gred_layers=args.num_gred_layers,
            num_transformer_layers=args.num_transformer_layers,
            num_heads=args.num_heads, expand=args.gred_expand,
            r_min=args.r_min, r_max=args.r_max, max_phase=args.max_phase,
            dropout=args.dropout, act=args.gred_act, output_dim=args.output_dim,
            lap_pe_dim=lap_pe_dim,
            cross_attn_router=cross_attn_router,
        )
    else:
        raise ValueError(f"Unknown backbone: {args.backbone}")


def build_generator(args):
    if args.generator == "score_based":
        return ScoreBasedGenerator(
            num_proxies=args.num_proxies,
            input_dim=args.hidden_dim,
            hidden_dim=args.gen_hidden_dim,
            num_layers=args.gen_num_layers,
            num_heads=args.gen_num_heads,
            dropout=args.gen_dropout,
        )
    elif args.generator == "pma":
        return PMAGenerator(
            num_proxies=args.num_proxies,
            input_dim=args.hidden_dim,
            num_heads=args.gen_num_heads,
            num_layers=args.gen_num_layers,
            dropout=args.gen_dropout,
            query_mode=args.pma_query_mode,
        )
    elif args.generator == "graph_coarsening":
        return GraphCoarseningGenerator(
            num_proxies=args.num_proxies,
            input_dim=args.hidden_dim,
            gnn_layers=args.gen_num_layers,
            gnn_type=args.coarsen_gnn_type,
            dropout=args.gen_dropout,
            reg_type=args.coarsen_reg_type,
            reg_weight=args.coarsen_reg_weight,
            num_refine_layers=1,
            num_heads=args.gen_num_heads,
        )
    elif args.generator == "gnn_pooling":
        return GNNPoolingGenerator(
            num_proxies=args.num_proxies,
            input_dim=args.hidden_dim,
            gnn_layers=args.gnn_layers,
            gnn_type=args.gnn_type,
            pool_types=tuple(args.pool_types),
            decode_hidden=args.decode_hidden,
            decode_layers=args.decode_layers,
            idx_emb_dim=args.idx_emb_dim,
            dropout=args.gen_dropout,
            decode_mode=args.decode_mode,
        )
    else:
        raise ValueError(f"Unknown generator: {args.generator}")


def _generate_proxies(model, generator, batch, dense_x, dense_mask, args,
                      gred_h=None):
    """
    Generate proxy embeddings for a batch.
    dense_x and dense_mask must be precomputed (possibly inside no_grad).
    For hybrid backbone, gred_h provides GRED-encoded features for the generator.
    Returns proxy_embeddings (B, M, d), aux_loss.
    """
    # For hybrid, generators consume GRED-encoded features (topology-aware)
    gen_input = gred_h if gred_h is not None else dense_x
    gen_mask = dense_mask

    if _uses_flat_interface(args.generator):
        flat_emb = gen_input[gen_mask]  # reconstruct flat from dense
        proxies, aux_loss = generator(
            flat_emb, mask=None,
            edge_index=batch.edge_index,
            batch_vec=batch.batch,
            edge_attr=getattr(batch, "edge_attr", None),
        )
    else:
        proxies, aux_loss = generator(gen_input, gen_mask)
    return proxies, aux_loss


@torch.no_grad()
def downstream_eval(model, generator, loader, device, args):
    """Evaluate generated proxies through frozen transformer. Returns (AP, loss)."""
    model.eval()
    if generator is not None:
        generator.eval()
    loss_fn = nn.BCEWithLogitsLoss()
    all_preds, all_labels, losses = [], [], []
    is_gred = args.backbone in ("gred", "hybrid")

    for batch_data in loader:
        if is_gred:
            batch, dist_masks_batch, node_masks_batch = batch_data
            batch = batch.to(device)
            dist_masks_batch = dist_masks_batch.to(device)
            node_masks_batch = node_masks_batch.to(device)
        else:
            batch = batch_data.to(device)
            dist_masks_batch = None
            node_masks_batch = None

        # Multi-point proxy path
        if hasattr(model, 'multi_point_proxy') and model.multi_point_proxy is not None:
            if args.backbone == "vanilla_gt":
                logits, _ = model(batch, readout_scope=args.readout_scope)
            elif args.backbone == "gred":
                logits, _ = model(batch, dist_masks_batch, node_masks_batch, readout_scope=args.readout_scope)
            elif args.backbone == "hybrid":
                logits, _ = model(batch, dist_masks_batch, node_masks_batch, readout_scope=args.readout_scope)
        else:
            # Standard single-point proxy path
            dense_x, dense_mask = model.encode_dense(batch)

            # For hybrid: run GRED encoding
            gred_h = None
            if args.backbone == "hybrid":
                gred_h = model.encode_gred(dense_x, dist_masks_batch, node_masks_batch)

            proxies, _ = _generate_proxies(
                model, generator, batch, dense_x, dense_mask, args, gred_h=gred_h)

            if args.backbone == "vanilla_gt":
                logits, _ = model(batch, proxy_embeddings=proxies,
                                  precomputed_dense=(dense_x, dense_mask), readout_scope=args.readout_scope)
            elif args.backbone == "gred":
                logits, _ = model(batch, dist_masks_batch, node_masks_batch, readout_scope=args.readout_scope)
            elif args.backbone == "hybrid":
                logits, _ = model(batch, dist_masks_batch, node_masks_batch,
                                  proxy_embeddings=proxies,
                                  precomputed_dense=(dense_x, dense_mask),
                                  precomputed_gred=gred_h, readout_scope=args.readout_scope)

        losses.append(loss_fn(logits, batch.y).item())
        all_preds.append(torch.sigmoid(logits).cpu().numpy())
        all_labels.append(batch.y.cpu().numpy())

    ap = compute_macro_ap(
        np.concatenate(all_preds, axis=0),
        np.concatenate(all_labels, axis=0),
    )
    return ap, float(np.mean(losses))


@torch.no_grad()
def mean_proxy_eval(model, generator, loader, device, args):
    """
    Sanity check: replace each proxy with the mean over the M dimension,
    then evaluate AP. If AP doesn't drop vs normal eval, proxies are inert.
    For multi-point proxy, this sanity check doesn't apply and is skipped.
    """
    model.eval()
    if generator is not None:
        generator.eval()

    # Skip for multi-point proxy (doesn't make sense)
    if hasattr(model, 'multi_point_proxy') and model.multi_point_proxy is not None:
        return float('nan')

    all_preds, all_labels = [], []
    is_gred = args.backbone in ("gred", "hybrid")

    for batch_data in loader:
        if is_gred:
            batch, dist_masks_batch, node_masks_batch = batch_data
            batch = batch.to(device)
            dist_masks_batch = dist_masks_batch.to(device)
            node_masks_batch = node_masks_batch.to(device)
        else:
            batch = batch_data.to(device)
            dist_masks_batch = None
            node_masks_batch = None

        dense_x, dense_mask = model.encode_dense(batch)

        gred_h = None
        if args.backbone == "hybrid":
            gred_h = model.encode_gred(dense_x, dist_masks_batch, node_masks_batch)

        proxies, _ = _generate_proxies(
            model, generator, batch, dense_x, dense_mask, args, gred_h=gred_h)
        # Replace proxies with their mean (collapse to virtual-node equivalent)
        mean_p = proxies.mean(dim=1, keepdim=True).expand_as(proxies)

        if args.backbone == "vanilla_gt":
            logits, _ = model(batch, proxy_embeddings=mean_p,
                              precomputed_dense=(dense_x, dense_mask), readout_scope=args.readout_scope)
        elif args.backbone == "hybrid":
            logits, _ = model(batch, dist_masks_batch, node_masks_batch,
                              proxy_embeddings=mean_p,
                              precomputed_dense=(dense_x, dense_mask),
                              precomputed_gred=gred_h, readout_scope=args.readout_scope)
        else:
            logits, _ = model(batch, dist_masks_batch, node_masks_batch, readout_scope=args.readout_scope)

        all_preds.append(torch.sigmoid(logits).cpu().numpy())
        all_labels.append(batch.y.cpu().numpy())

    return compute_macro_ap(
        np.concatenate(all_preds, axis=0),
        np.concatenate(all_labels, axis=0),
    )


# ================================================================
# STAGE 1 - PRETRAIN TRANSFORMER (identical to main_staged.py)
# ================================================================

def run_stage1(args):
    print("\n" + "=" * 60, flush=True)
    print("STAGE 1: Pretrain Model", flush=True)
    print(f"  Backbone: {args.backbone}", flush=True)
    print("=" * 60, flush=True)
    is_gred = args.backbone in ("gred", "hybrid")

    train_loader, val_loader, test_loader, _, _, _ = get_loaders(
        batch_size=args.batch_size, num_workers=args.num_workers,
        use_dist_masks=is_gred, max_hops=args.max_hops,
        dist_mask_workers=args.dist_mask_workers,
        use_lap_pe=args.use_lap_pe, lap_pe_dim=args.lap_pe_dim,
    )

    model = build_model(args).to(args.device)

    print(f"  Parameters: {sum(p.numel() for p in model.parameters()):,}", flush=True)

    total_steps = max(1, len(train_loader) * args.s1_max_epochs)
    optimizer, scheduler = build_grouped_optimizer_and_scheduler(
        named_parameters=[(f"model.{name}", param) for name, param in model.named_parameters()],
        lr_max=args.s1_lr,
        lr_min=args.lr_min,
        weight_decay=args.s1_weight_decay,
        total_steps=total_steps,
        warmup_ratio=args.warmup_ratio,
        recurrent_lr_factor=args.recurrent_lr_factor,
    )
    loss_fn = nn.BCEWithLogitsLoss()

    best_val_ap = 0.0
    best_val_loss = float("inf")
    best_epoch = -1
    patience_counter = 0
    save_path = os.path.join(args.save_dir, "stage1_best.pt")

    for epoch in range(1, args.s1_max_epochs + 1):
        epoch_start = time.time()

        model.train()
        train_losses, all_preds, all_labels = [], [], []

        for batch_data in train_loader:
            if is_gred:
                batch, dist_masks_batch, node_masks_batch = batch_data
                batch = batch.to(args.device)
                dist_masks_batch = dist_masks_batch.to(args.device)
                node_masks_batch = node_masks_batch.to(args.device)
            else:
                batch = batch_data.to(args.device)
                dist_masks_batch = None
                node_masks_batch = None

            optimizer.zero_grad()
            if args.backbone == "vanilla_gt":
                logits, _ = model(batch, readout_scope=args.readout_scope)
            elif args.backbone == "gred":
                logits, _ = model(batch, dist_masks_batch, node_masks_batch, readout_scope=args.readout_scope)
            elif args.backbone == "hybrid":
                logits, _ = model(batch, dist_masks_batch, node_masks_batch, readout_scope=args.readout_scope)
            loss = loss_fn(logits, batch.y)
            loss.backward()
            nn.utils.clip_grad_norm_(model.parameters(), args.s1_grad_clip)
            optimizer.step()
            scheduler.step()
            train_losses.append(loss.item())
            all_preds.append(torch.sigmoid(logits).detach().cpu().numpy())
            all_labels.append(batch.y.cpu().numpy())

        train_ap = compute_macro_ap(np.concatenate(all_preds), np.concatenate(all_labels))
        train_loss = float(np.mean(train_losses))

        model.eval()
        val_preds, val_labels, val_losses = [], [], []
        with torch.no_grad():
            for batch_data in val_loader:
                if is_gred:
                    batch, dist_masks_batch, node_masks_batch = batch_data
                    batch = batch.to(args.device)
                    dist_masks_batch = dist_masks_batch.to(args.device)
                    node_masks_batch = node_masks_batch.to(args.device)
                else:
                    batch = batch_data.to(args.device)
                    dist_masks_batch = None
                    node_masks_batch = None

                if args.backbone == "vanilla_gt":
                    logits, _ = model(batch, readout_scope=args.readout_scope)
                else:
                    logits, _ = model(batch, dist_masks_batch, node_masks_batch, readout_scope=args.readout_scope)
                val_losses.append(loss_fn(logits, batch.y).item())
                val_preds.append(torch.sigmoid(logits).cpu().numpy())
                val_labels.append(batch.y.cpu().numpy())
        val_ap = compute_macro_ap(np.concatenate(val_preds), np.concatenate(val_labels))
        val_loss = float(np.mean(val_losses))

        elapsed = time.time() - epoch_start
        mem_str = ""
        if args.device.startswith("cuda"):
            mem_mb = torch.cuda.max_memory_allocated() / 1024 / 1024
            mem_str = f" mem={mem_mb:.0f}MB"
            torch.cuda.reset_peak_memory_stats()
        log_line = (f"Epoch {epoch:3d}/{args.s1_max_epochs} [{elapsed:.1f}s{mem_str}] | "
                    f"train_loss={train_loss:.4f} train_AP={train_ap:.4f} | "
                    f"val_loss={val_loss:.4f} val_AP={val_ap:.4f}")

        if epoch % 10 == 0:
            model.eval()
            test_preds, test_labels = [], []
            with torch.no_grad():
                for batch_data in test_loader:
                    if is_gred:
                        batch, dist_masks_batch, node_masks_batch = batch_data
                        batch = batch.to(args.device)
                        dist_masks_batch = dist_masks_batch.to(args.device)
                        node_masks_batch = node_masks_batch.to(args.device)
                    else:
                        batch = batch_data.to(args.device)
                        dist_masks_batch = None
                        node_masks_batch = None

                    if args.backbone == "vanilla_gt":
                        logits, _ = model(batch, readout_scope=args.readout_scope)
                    else:
                        logits, _ = model(batch, dist_masks_batch, node_masks_batch, readout_scope=args.readout_scope)
                    test_preds.append(torch.sigmoid(logits).cpu().numpy())
                    test_labels.append(batch.y.cpu().numpy())
            test_ap = compute_macro_ap(np.concatenate(test_preds), np.concatenate(test_labels))
            log_line += f" | test_AP={test_ap:.4f}"

        print(log_line, flush=True)

        improved_val_loss = val_loss < best_val_loss
        improved_val_ap = val_ap > best_val_ap
        if improved_val_loss or improved_val_ap:
            if improved_val_loss:
                best_val_loss = val_loss
            if improved_val_ap:
                best_val_ap = val_ap
            best_epoch = epoch
            patience_counter = 0
            torch.save({
                "model_state": model.state_dict(),
                "epoch": epoch, "val_ap": val_ap,
                "args": vars(args),
            }, save_path)
            print(
                f"  -> New best metrics: val_loss={best_val_loss:.4f} val_AP={best_val_ap:.4f}, saved",
                flush=True,
            )
        else:
            patience_counter += 1
            if patience_counter >= args.s1_patience:
                print(f"Early stopping at epoch {epoch}. "
                      f"Best val loss={best_val_loss:.4f} at epoch {best_epoch}.", flush=True)
                break

    print(f"Stage 1 done. Best val loss={best_val_loss:.4f} at epoch {best_epoch}.", flush=True)
    return save_path


# ================================================================
# STAGE 2 - TRAIN GENERATOR ON TASK LOSS (NEW)
# ================================================================

def _proxy_cosine_sim(proxies):
    """Mean pairwise cosine similarity among M proxies (off-diagonal). Scalar."""
    B, M, d = proxies.shape
    if M < 2:
        return 0.0
    with torch.no_grad():
        pn = F.normalize(proxies.detach(), dim=-1)         # (B, M, d)
        cos = torch.bmm(pn, pn.transpose(1, 2))            # (B, M, M)
        mask_diag = ~torch.eye(M, dtype=torch.bool, device=proxies.device)
        return cos[:, mask_diag].mean().item()


def _attention_entropy(generator, dense_x, dense_mask):
    """
    Per-epoch attention weight entropy for ScoreBasedGenerator.
    Higher entropy = more uniform attention (virtual-node averaging).
    Lower entropy = peaked attention (selective).
    """
    with torch.no_grad():
        S = generator.score_mlp(dense_x)                   # (B, N, M)
        S = S.masked_fill(~dense_mask.unsqueeze(-1), float("-inf"))
        A = F.softmax(S, dim=1)                             # (B, N, M)
        A = torch.nan_to_num(A, nan=0.0)
        # Entropy per proxy: -sum_n A_n * log(A_n + eps)
        entropy = -(A * (A + 1e-8).log()).sum(dim=1).mean()
        return entropy.item()


def run_stage2(args, model_path):
    print("\n" + "=" * 60, flush=True)
    print(f"STAGE 2: Train Generator ({args.generator}) on Task Loss", flush=True)
    print(f"  Backbone: {args.backbone}", flush=True)
    print(f"  LR={args.s2_lr}, patience={args.s2_patience}, max_epochs={args.s2_max_epochs}",
          flush=True)
    if _parse_insertion_layers(args.proxy_insertion_layers) is not None:
        print(f"  Multi-point proxy insertion layers: {_parse_insertion_layers(args.proxy_insertion_layers)}", flush=True)
    print("=" * 60, flush=True)
    is_gred = args.backbone in ("gred", "hybrid")

    train_loader, val_loader, test_loader, _, _, _ = get_loaders(
        batch_size=args.batch_size, num_workers=args.num_workers,
        use_dist_masks=is_gred, max_hops=args.max_hops,
        dist_mask_workers=args.dist_mask_workers,
        use_lap_pe=args.use_lap_pe, lap_pe_dim=args.lap_pe_dim,
    )

    # Load and freeze model
    model = build_model(args).to(args.device)
    ckpt = torch.load(model_path, map_location=args.device, weights_only=True)
    model.load_state_dict(ckpt["model_state"])
    _freeze(model)
    model.eval()

    generator = build_generator(args).to(args.device)
    print(f"  Generator parameters: {sum(p.numel() for p in generator.parameters()):,}",
          flush=True)

    # Build multi-point proxy wrapper if enabled
    router = None  # Stage 2 doesn't use cross-attention routing
    multi_point_proxy = _build_multi_point_proxy(args, generator, router)
    if multi_point_proxy is not None:
        model.multi_point_proxy = multi_point_proxy
        print(f"  Multi-point proxy wrapper attached", flush=True)

    total_steps = max(1, len(train_loader) * args.s2_max_epochs)
    # For multi-point proxy, generator is inside the wrapper and already in model.parameters()
    if multi_point_proxy is not None:
        named_params = [(f"multi_point_proxy.{name}", param)
                        for name, param in model.multi_point_proxy.named_parameters()]
    else:
        named_params = [(f"generator.{name}", param) for name, param in generator.named_parameters()]

    optimizer, scheduler = build_grouped_optimizer_and_scheduler(
        named_parameters=named_params,
        lr_max=args.s2_lr,
        lr_min=args.lr_min,
        weight_decay=args.s2_weight_decay,
        total_steps=total_steps,
        warmup_ratio=args.warmup_ratio,
        recurrent_lr_factor=1.0,
    )
    loss_fn = nn.BCEWithLogitsLoss()

    best_val_ap = 0.0
    best_val_loss = float("inf")
    best_gen_loss = float("inf")
    best_epoch = -1
    patience_counter = 0
    diagnostics = []
    save_path = os.path.join(args.save_dir, "stage2_generator.pt")

    for epoch in range(1, args.s2_max_epochs + 1):
        epoch_start = time.time()

        generator.train()
        train_losses = []
        epoch_cos_sims = []
        epoch_entropies = []
        epoch_grad_norms = []
        epoch_novelty_losses = []
        epoch_diversity_losses = []
        last_dense_x = last_dense_mask = None  # for entropy diagnostic

        for batch_data in train_loader:
            if is_gred:
                batch, dist_masks_batch, node_masks_batch = batch_data
                batch = batch.to(args.device)
                dist_masks_batch = dist_masks_batch.to(args.device)
                node_masks_batch = node_masks_batch.to(args.device)
            else:
                batch = batch_data.to(args.device)
                dist_masks_batch = None
                node_masks_batch = None

            # Encode with frozen model (no grad through encoder)
            with torch.no_grad():
                dense_x, dense_mask = model.encode_dense(batch)
                gred_h = None
                if args.backbone == "hybrid":
                    gred_h = model.encode_gred(dense_x, dist_masks_batch, node_masks_batch)

            optimizer.zero_grad()

            # Multi-point proxy path
            if model.multi_point_proxy is not None:
                if args.backbone == "vanilla_gt":
                    logits, _ = model(batch, precomputed_dense=(dense_x, dense_mask), readout_scope=args.readout_scope)
                elif args.backbone == "hybrid":
                    logits, _ = model(batch, dist_masks_batch, node_masks_batch,
                                      precomputed_dense=(dense_x, dense_mask),
                                      precomputed_gred=gred_h, readout_scope=args.readout_scope)
                elif args.backbone == "gred":
                    logits, _ = model(batch, dist_masks_batch, node_masks_batch, readout_scope=args.readout_scope)
                aux_loss = getattr(model, '_last_mp_aux_loss', None)
                if aux_loss is not None and not isinstance(aux_loss, torch.Tensor):
                    aux_loss = torch.tensor(aux_loss, device=batch.x.device)
                # For multi-point proxy, skip novelty and diversity loss
                task_loss = loss_fn(logits, batch.y)
                loss = task_loss
                if aux_loss is not None:
                    loss = loss + aux_loss
                novelty_loss_val = 0.0
                diversity_loss_val = 0.0
                proxies = None
            else:
                # Standard single-point proxy path
                proxies, aux_loss = _generate_proxies(
                    model, generator, batch, dense_x, dense_mask, args, gred_h=gred_h)

                # Forward through frozen model with generated proxies
                if args.backbone == "vanilla_gt":
                    logits, node_emb = model(batch, proxy_embeddings=proxies,
                                      precomputed_dense=(dense_x, dense_mask), readout_scope=args.readout_scope)
                elif args.backbone == "hybrid":
                    logits, node_emb = model(batch, dist_masks_batch, node_masks_batch,
                                      proxy_embeddings=proxies,
                                      precomputed_dense=(dense_x, dense_mask),
                                      precomputed_gred=gred_h, readout_scope=args.readout_scope)
                elif args.backbone == "gred":
                    logits, node_emb = model(batch, dist_masks_batch, node_masks_batch, readout_scope=args.readout_scope)
                    node_emb = None  # GRED has no proxy path, no novelty loss

                task_loss = loss_fn(logits, batch.y)
                loss = task_loss
                if aux_loss is not None:
                    loss = loss + aux_loss

                # Novelty loss (if enabled)
                novelty_loss_val = 0.0
                if args.novelty_alpha > 0.0 and args.backbone != "gred":
                    # Compute novelty loss: proxy-node cosine similarity
                    nov_loss = novelty_loss(proxies, dense_x, node_mask=dense_mask)
                    loss = loss + args.novelty_alpha * nov_loss
                    novelty_loss_val = (args.novelty_alpha * nov_loss).item()

                # Diversity loss (if enabled)
                diversity_loss_val = 0.0
                if args.diversity_weight > 0.0 and proxies is not None:
                    div_loss = proxy_diversity_loss(proxies)
                    loss = loss + args.diversity_weight * div_loss
                    diversity_loss_val = (args.diversity_weight * div_loss).item()

            loss.backward()

            # Gradient norm diagnostic (before clipping)
            grad_norm = sum(
                p.grad.norm().item() ** 2
                for p in generator.parameters() if p.grad is not None
            ) ** 0.5
            epoch_grad_norms.append(grad_norm)

            nn.utils.clip_grad_norm_(generator.parameters(), args.s2_grad_clip)
            optimizer.step()
            scheduler.step()

            train_losses.append(loss.item())
            if proxies is not None:
                epoch_cos_sims.append(_proxy_cosine_sim(proxies))
            epoch_novelty_losses.append(novelty_loss_val)
            epoch_diversity_losses.append(diversity_loss_val)

            # Save tensors for attention entropy (score_based only, last batch)
            if args.generator == "score_based":
                last_dense_x = dense_x.detach()
                last_dense_mask = dense_mask.detach()

        mean_train_loss = float(np.mean(train_losses))
        mean_cos_sim = float(np.mean(epoch_cos_sims)) if epoch_cos_sims else float('nan')
        mean_grad_norm = float(np.mean(epoch_grad_norms))
        mean_novelty_loss = float(np.mean(epoch_novelty_losses))
        mean_diversity_loss = float(np.mean(epoch_diversity_losses))

        if args.generator == "score_based" and last_dense_x is not None:
            attn_entropy = _attention_entropy(generator, last_dense_x, last_dense_mask)
        else:
            attn_entropy = float("nan")

        # Downstream evaluation
        if epoch % args.s2_eval_every == 0:
            val_ap, val_loss = downstream_eval(model, generator, val_loader, args.device, args)
            test_ap, _ = downstream_eval(model, generator, test_loader, args.device, args)

            # Sanity check: mean-proxy AP
            mean_ap = mean_proxy_eval(model, generator, val_loader, args.device, args)
            proxy_delta = val_ap - mean_ap  # positive = proxies add value

            elapsed = time.time() - epoch_start
            mem_str = ""
            if args.device.startswith("cuda"):
                mem_mb = torch.cuda.max_memory_allocated() / 1024 / 1024
                mem_str = f" mem={mem_mb:.0f}MB"
                torch.cuda.reset_peak_memory_stats()

            print(
                f"Epoch {epoch:3d}/{args.s2_max_epochs} [{elapsed:.1f}s{mem_str}] | "
                f"task_loss={mean_train_loss:.4f} | "
                f"val_AP={val_ap:.4f} mean_AP={mean_ap:.4f} delta={proxy_delta:+.4f} | "
                f"test_AP={test_ap:.4f} | "
                f"cos_sim={mean_cos_sim:.4f} grad_norm={mean_grad_norm:.4f} "
                f"attn_entr={attn_entropy:.4f} | "
                f"novelty_loss={mean_novelty_loss:.4f} diversity_loss={mean_diversity_loss:.4f}",
                flush=True,
            )

            diagnostics.append({
                "epoch": epoch,
                "task_loss": mean_train_loss,
                "val_ap": val_ap,
                "test_ap": test_ap,
                "mean_proxy_val_ap": mean_ap,
                "proxy_delta": proxy_delta,
                "cos_sim": mean_cos_sim,
                "grad_norm": mean_grad_norm,
                "attn_entropy": attn_entropy,
            })

            improved_gen_loss = mean_train_loss < best_gen_loss
            improved_val_loss = val_loss < best_val_loss
            improved_val_ap = val_ap > best_val_ap
            if improved_gen_loss or improved_val_loss or improved_val_ap:
                if improved_gen_loss:
                    best_gen_loss = mean_train_loss
                if improved_val_loss:
                    best_val_loss = val_loss
                if improved_val_ap:
                    best_val_ap = val_ap
                best_epoch = epoch
                patience_counter = 0
                torch.save({
                    "generator_state": generator.state_dict(),
                    "epoch": epoch, "val_ap": val_ap, "test_ap": test_ap,
                    "args": vars(args),
                }, save_path)
                print(
                    f"  -> New best metrics: gen_loss={best_gen_loss:.4f} "
                    f"val_loss={best_val_loss:.4f} val_AP={best_val_ap:.4f}",
                    flush=True,
                )
            else:
                patience_counter += 1
                if patience_counter >= args.s2_patience:
                    print(f"Early stopping at epoch {epoch}. "
                          f"Best val loss={best_val_loss:.4f} at epoch {best_epoch}.", flush=True)
                    break
        else:
            elapsed = time.time() - epoch_start
            print(f"Epoch {epoch:3d}/{args.s2_max_epochs} [{elapsed:.1f}s] | "
                  f"task_loss={mean_train_loss:.4f} | "
                  f"cos_sim={mean_cos_sim:.4f} grad_norm={mean_grad_norm:.4f} | "
                  f"novelty_loss={mean_novelty_loss:.4f} diversity_loss={mean_diversity_loss:.4f}",
                  flush=True)

    diag_path = os.path.join(args.save_dir, "stage2_diagnostics.pkl")
    with open(diag_path, "wb") as f:
        pickle.dump(diagnostics, f)
    print(f"Stage 2 done. Best val loss={best_val_loss:.4f} at epoch {best_epoch}.", flush=True)
    print(f"Diagnostics saved to {diag_path}", flush=True)
    return save_path


# ================================================================
# STAGE 3 - END-TO-END FINETUNE (Phase A + Phase B + proxy dropout)
# ================================================================

def run_stage3(args, model_path, generator_path):
    print("\n" + "=" * 60, flush=True)
    print("STAGE 3: End-to-End Finetune", flush=True)
    print(f"  Backbone: {args.backbone}", flush=True)
    print(f"  Phase A: {args.s3_phase_a_epochs} epochs (frozen model, "
          f"gen_lr={args.s3_lr_gen:.2e})", flush=True)
    print(f"  Phase B: unfreeze model at lr={args.s3_lr_transformer:.2e}, "
          f"gen_lr={args.s3_lr_gen:.2e}", flush=True)
    print(f"  Proxy dropout: {args.s3_proxy_dropout}", flush=True)
    if _parse_insertion_layers(args.proxy_insertion_layers) is not None:
        print(f"  Multi-point proxy insertion layers: {_parse_insertion_layers(args.proxy_insertion_layers)}", flush=True)
    print("=" * 60, flush=True)
    is_gred = args.backbone in ("gred", "hybrid")

    train_loader, val_loader, test_loader, _, _, _ = get_loaders(
        batch_size=args.batch_size, num_workers=args.num_workers,
        use_dist_masks=is_gred, max_hops=args.max_hops,
        dist_mask_workers=args.dist_mask_workers,
        use_lap_pe=args.use_lap_pe, lap_pe_dim=args.lap_pe_dim,
    )

    # Load model
    model = build_model(args).to(args.device)
    model_ckpt = torch.load(model_path, map_location=args.device, weights_only=True)
    model.load_state_dict(model_ckpt["model_state"])

    # Load generator
    generator = build_generator(args).to(args.device)
    gen_ckpt = torch.load(generator_path, map_location=args.device, weights_only=True)
    generator.load_state_dict(gen_ckpt["generator_state"])

    # Build multi-point proxy wrapper if enabled
    router = None  # Stage 3 doesn't use cross-attention routing
    multi_point_proxy = _build_multi_point_proxy(args, generator, router)
    if multi_point_proxy is not None:
        model.multi_point_proxy = multi_point_proxy
        print(f"  Multi-point proxy wrapper attached", flush=True)

    loss_fn = nn.BCEWithLogitsLoss()

    # Phase A optimizer: generator only, transformer frozen
    _freeze(model)
    # If multi-point is active, unfreeze the wrapper
    if multi_point_proxy is not None:
        _unfreeze(model.multi_point_proxy)

    phase_a_epochs = min(args.s3_phase_a_epochs, args.s3_max_epochs)
    phase_a_total_steps = max(1, len(train_loader) * max(phase_a_epochs, 1))
    phase_b_total_steps = max(1, len(train_loader) * max(args.s3_max_epochs - phase_a_epochs, 1))

    # For multi-point proxy, generator is inside the wrapper
    if multi_point_proxy is not None:
        phase_a_named_params = [(f"multi_point_proxy.{name}", param)
                                for name, param in model.multi_point_proxy.named_parameters()]
    else:
        phase_a_named_params = [(f"generator.{name}", param) for name, param in generator.named_parameters()]

    opt_a, sched_a = build_grouped_optimizer_and_scheduler(
        named_parameters=phase_a_named_params,
        lr_max=args.s3_lr_gen,
        lr_min=args.lr_min,
        weight_decay=args.s3_weight_decay,
        total_steps=phase_a_total_steps,
        warmup_ratio=args.warmup_ratio,
        recurrent_lr_factor=1.0,
    )

    # Phase B optimizer: built once Phase B starts
    opt_b = None
    sched_b = None

    best_val_ap = 0.0
    best_val_loss = float("inf")
    best_gen_loss = float("inf")
    best_epoch = -1
    patience_counter = 0
    phase = "A"
    save_path = os.path.join(args.save_dir, "stage3_best.pt")

    for epoch in range(1, args.s3_max_epochs + 1):
        epoch_start = time.time()

        # Phase transition
        if epoch > args.s3_phase_a_epochs and phase == "A":
            phase = "B"
            _unfreeze(model)
            # If multi-point is active, keep it unfrozen (it was unfrozen in phase A)
            if multi_point_proxy is not None:
                _unfreeze(model.multi_point_proxy)
            # Build parameter groups based on backbone type
            if args.backbone == "vanilla_gt":
                model_param_groups = [
                    {"params": model.encoder.parameters(), "lr": args.s3_lr_transformer},
                    {"params": model.layers.parameters(), "lr": args.s3_lr_transformer},
                    {"params": model.head.parameters(), "lr": args.s3_lr_transformer},
                ]
            elif args.backbone == "gred":
                model_param_groups = [
                    {"params": model.encoder.parameters(), "lr": args.s3_lr_transformer},
                    {"params": model.layers.parameters(), "lr": args.s3_lr_transformer},
                    {"params": model.head.parameters(), "lr": args.s3_lr_transformer},
                ]
            elif args.backbone == "hybrid":
                model_param_groups = [
                    {"params": model.encoder.parameters(), "lr": args.s3_lr_transformer},
                    {"params": model.gred_layers.parameters(), "lr": args.s3_lr_transformer},
                    {"params": model.transformer_layers.parameters(), "lr": args.s3_lr_transformer},
                    {"params": model.head.parameters(), "lr": args.s3_lr_transformer},
                ]

            # For multi-point proxy, generator is inside the wrapper, don't add separately
            if multi_point_proxy is not None:
                gen_param_groups = [{"params": model.multi_point_proxy.parameters(), "lr": args.s3_lr_gen}]
            else:
                gen_param_groups = [{"params": generator.parameters(), "lr": args.s3_lr_gen}]

            opt_b = torch.optim.AdamW(
                model_param_groups + gen_param_groups,
                weight_decay=args.s3_weight_decay,
            )
            sched_b = build_warmup_cosine_scheduler(
                optimizer=opt_b,
                total_steps=phase_b_total_steps,
                lr_min=args.lr_min,
                warmup_ratio=args.warmup_ratio,
            )
            print(f"  [Epoch {epoch}] Switching to Phase B — model unfrozen.", flush=True)

        optimizer = opt_a if phase == "A" else opt_b
        scheduler = sched_a if phase == "A" else sched_b

        model.train()
        generator.train()
        train_losses, all_preds, all_labels = [], [], []
        epoch_novelty_losses = []
        epoch_diversity_losses = []

        for batch_data in train_loader:
            if is_gred:
                batch, dist_masks_batch, node_masks_batch = batch_data
                batch = batch.to(args.device)
                dist_masks_batch = dist_masks_batch.to(args.device)
                node_masks_batch = node_masks_batch.to(args.device)
            else:
                batch = batch_data.to(args.device)
                dist_masks_batch = None
                node_masks_batch = None

            optimizer.zero_grad()

            # Multi-point proxy path
            if model.multi_point_proxy is not None:
                # Multi-point proxy handles generation internally
                if phase == "A":
                    use_proxy = True
                else:
                    # Phase B: randomly skip proxies for a fraction of batches.
                    use_proxy = torch.rand(1).item() > args.s3_proxy_dropout

                if use_proxy:
                    if args.backbone == "vanilla_gt":
                        logits, _ = model(batch, readout_scope=args.readout_scope)
                    elif args.backbone == "hybrid":
                        logits, _ = model(batch, dist_masks_batch, node_masks_batch, readout_scope=args.readout_scope)
                    elif args.backbone == "gred":
                        logits, _ = model(batch, dist_masks_batch, node_masks_batch, readout_scope=args.readout_scope)
                    aux_loss = getattr(model, '_last_mp_aux_loss', None)
                    if aux_loss is not None and not isinstance(aux_loss, torch.Tensor):
                        aux_loss = torch.tensor(aux_loss, device=batch.x.device)
                else:
                    # Without proxies, model is frozen in phase A, so this shouldn't happen
                    if args.backbone == "vanilla_gt":
                        logits, _ = model(batch, readout_scope=args.readout_scope)
                    elif args.backbone == "hybrid":
                        logits, _ = model(batch, dist_masks_batch, node_masks_batch, readout_scope=args.readout_scope)
                    elif args.backbone == "gred":
                        logits, _ = model(batch, dist_masks_batch, node_masks_batch, readout_scope=args.readout_scope)
                    aux_loss = None

                # For multi-point proxy, skip novelty and diversity loss
                task_loss = loss_fn(logits, batch.y)
                loss = task_loss
                if aux_loss is not None:
                    loss = loss + aux_loss
                novelty_loss_val = 0.0
                diversity_loss_val = 0.0
            else:
                # Standard single-point proxy path
                dense_x, dense_mask = model.encode_dense(batch)

                gred_h = None
                if args.backbone == "hybrid":
                    gred_h = model.encode_gred(dense_x, dist_masks_batch, node_masks_batch)

                # In Phase A the model is frozen, so proxies must be used
                # to keep a valid gradient path to the generator.
                if phase == "A":
                    use_proxy = True
                else:
                    # Phase B: randomly skip proxies for a fraction of batches.
                    use_proxy = torch.rand(1).item() > args.s3_proxy_dropout

                if use_proxy:
                    proxies, aux_loss = _generate_proxies(
                        model, generator, batch, dense_x, dense_mask, args, gred_h=gred_h)
                    if args.backbone == "vanilla_gt":
                        logits, node_emb = model(batch, proxy_embeddings=proxies,
                                          precomputed_dense=(dense_x, dense_mask), readout_scope=args.readout_scope)
                    elif args.backbone == "hybrid":
                        logits, node_emb = model(batch, dist_masks_batch, node_masks_batch,
                                          proxy_embeddings=proxies,
                                          precomputed_dense=(dense_x, dense_mask),
                                          precomputed_gred=gred_h, readout_scope=args.readout_scope)
                    elif args.backbone == "gred":
                        logits, node_emb = model(batch, dist_masks_batch, node_masks_batch, readout_scope=args.readout_scope)
                        node_emb = None  # GRED has no proxy path

                    task_loss = loss_fn(logits, batch.y)
                    loss = task_loss
                    if aux_loss is not None:
                        loss = loss + aux_loss

                    # Novelty loss (if enabled)
                    novelty_loss_val = 0.0
                    if args.novelty_alpha > 0.0 and args.backbone != "gred":
                        # Compute novelty loss: proxy-node cosine similarity
                        nov_loss = novelty_loss(proxies, dense_x, node_mask=dense_mask)
                        loss = loss + args.novelty_alpha * nov_loss
                        novelty_loss_val = (args.novelty_alpha * nov_loss).item()

                    # Diversity loss (if enabled)
                    diversity_loss_val = 0.0
                    if args.diversity_weight > 0.0 and proxies is not None:
                        div_loss = proxy_diversity_loss(proxies)
                        loss = loss + args.diversity_weight * div_loss
                        diversity_loss_val = (args.diversity_weight * div_loss).item()
                else:
                    if args.backbone == "vanilla_gt":
                        logits, _ = model(batch, precomputed_dense=(dense_x, dense_mask), readout_scope=args.readout_scope)
                    else:
                        logits, _ = model(batch, dist_masks_batch, node_masks_batch,
                                          precomputed_dense=(dense_x, dense_mask),
                                          precomputed_gred=gred_h, readout_scope=args.readout_scope)
                    task_loss = loss_fn(logits, batch.y)
                    loss = task_loss
                    aux_loss = None
                    # When use_proxy=False (proxy dropout), skip novelty and diversity
                    novelty_loss_val = 0.0
                    diversity_loss_val = 0.0

            loss.backward()

            params_to_clip = list(generator.parameters())
            if phase == "B":
                params_to_clip += list(model.parameters())
            nn.utils.clip_grad_norm_(params_to_clip, args.s3_grad_clip)
            optimizer.step()
            scheduler.step()

            train_losses.append(loss.item())
            all_preds.append(torch.sigmoid(logits).detach().cpu().numpy())
            all_labels.append(batch.y.cpu().numpy())
            epoch_novelty_losses.append(novelty_loss_val)
            epoch_diversity_losses.append(diversity_loss_val)

        train_ap = compute_macro_ap(np.concatenate(all_preds), np.concatenate(all_labels))
        train_loss = float(np.mean(train_losses))
        mean_novelty_loss = float(np.mean(epoch_novelty_losses))
        mean_diversity_loss = float(np.mean(epoch_diversity_losses))

        val_ap, val_loss = downstream_eval(model, generator, val_loader, args.device, args)
        test_ap, _ = downstream_eval(model, generator, test_loader, args.device, args)

        elapsed = time.time() - epoch_start
        mem_str = ""
        if args.device.startswith("cuda"):
            mem_mb = torch.cuda.max_memory_allocated() / 1024 / 1024
            mem_str = f" mem={mem_mb:.0f}MB"
            torch.cuda.reset_peak_memory_stats()
        print(
            f"Epoch {epoch:3d}/{args.s3_max_epochs} [{phase}][{elapsed:.1f}s{mem_str}] | "
            f"train_loss={train_loss:.4f} train_AP={train_ap:.4f} | "
            f"val_loss={val_loss:.4f} val_AP={val_ap:.4f} | "
            f"test_AP={test_ap:.4f} | "
            f"novelty_loss={mean_novelty_loss:.4f} diversity_loss={mean_diversity_loss:.4f}",
            flush=True,
        )

        improved_gen_loss = train_loss < best_gen_loss
        improved_val_loss = val_loss < best_val_loss
        improved_val_ap = val_ap > best_val_ap
        if improved_gen_loss or improved_val_loss or improved_val_ap:
            if improved_gen_loss:
                best_gen_loss = train_loss
            if improved_val_loss:
                best_val_loss = val_loss
            if improved_val_ap:
                best_val_ap = val_ap
            best_epoch = epoch
            patience_counter = 0
            torch.save({
                "model_state": model.state_dict(),
                "generator_state": generator.state_dict(),
                "epoch": epoch, "val_ap": val_ap, "test_ap": test_ap,
                "args": vars(args),
            }, save_path)
            print(
                f"  -> New best metrics: gen_loss={best_gen_loss:.4f} "
                f"val_loss={best_val_loss:.4f} val_AP={best_val_ap:.4f} (test={test_ap:.4f})",
                flush=True,
            )
        else:
            patience_counter += 1
            if patience_counter >= args.s3_patience:
                print(f"Early stopping at epoch {epoch}. "
                      f"Best val loss={best_val_loss:.4f} at epoch {best_epoch}.", flush=True)
                break

    print(f"Stage 3 done. Best val loss={best_val_loss:.4f} at epoch {best_epoch}.", flush=True)
    return save_path


# ================================================================
# MAIN
# ================================================================

if __name__ == "__main__":
    args = parse_args()
    os.makedirs(args.save_dir, exist_ok=True)
    save_code_snapshot(args.save_dir)

    stages = [args.stage] if args.stage != "all" else ["1", "2", "3"]
    model_path = args.model_path
    generator_path = args.generator_path

    for stage in stages:
        if stage == "1":
            model_path = run_stage1(args)

        elif stage == "2":
            if model_path is None:
                model_path = os.path.join(args.save_dir, "stage1_best.pt")
            assert os.path.exists(model_path), \
                f"Stage 2 requires pretrained model at {model_path}"
            generator_path = run_stage2(args, model_path)

        elif stage == "3":
            if model_path is None:
                model_path = os.path.join(args.save_dir, "stage1_best.pt")
            if generator_path is None:
                generator_path = os.path.join(args.save_dir, "stage2_generator.pt")
            assert os.path.exists(model_path), \
                f"Stage 3 requires pretrained model at {model_path}"
            assert os.path.exists(generator_path), \
                f"Stage 3 requires trained generator at {generator_path}"
            run_stage3(args, model_path, generator_path)

    print("\nAll requested stages complete.", flush=True)
